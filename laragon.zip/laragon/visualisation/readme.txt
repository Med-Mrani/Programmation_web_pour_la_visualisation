Visualisation des heures par compétence — BUT Science des Données
=================================================================

Une petite application Node.js + SQLite + Chart.js permettant de visualiser
la répartition des heures par compétence dans le cadre du BUT Science des Données.

Fonctionnalités
---------------

- Initialise automatiquement une base SQLite à partir du script SQL fourni
- Expose une API REST (/api/heures) qui renvoie le total d’heures par compétence
- Affiche un graphe interactif (barres) des heures sur une page web
- Code léger et facilement extensible (par exemple, ajout d’un graphe par semestre)

Structure du projet
------------------

but-sd-app/
│
├── server.js          # Serveur Node.js / Express
├── init_db.sql        # Script SQL : création des tables et insertion des données
├── package.json       # Configuration du projet
├── public/
│   └── index.html     # Page web affichant le graphique (Chart.js)
└── README.txt         # Ce fichier

Installation et exécution
------------------------

Prérequis :
- Node.js >= 18
- npm (installé avec Node.js)

Installation :
1. Cloner le dépôt ou copier les fichiers
2. Installer les dépendances :
   npm install
   Cela installe :
   - express : serveur web
   - better-sqlite3 : moteur SQLite rapide et intégré

Démarrage du serveur :
   npm start

Le serveur démarre sur : http://localhost:3000

Description technique
---------------------

Base de données :
- COMPETENCE : contient les six compétences du BUT SD
- ACTIVITE_PEDAGOGIQUE : liste des activités et de leur association à une compétence

Les tables et leurs données sont créées automatiquement à partir du fichier init_db.sql.

API REST :
Méthode | Route       | Description
--------|------------|------------
GET     | /api/heures | Renvoie le total d’heures par compétence

Frontend :
Le fichier public/index.html utilise Chart.js pour représenter les données sous
forme de graphique à barres.

Exemple de visualisation :
C1 - Collecter, préparer et stocker les données     ████████████ 115 h
C2 - Analyser statistiquement les données            ██████ 105 h
C3 - Concevoir et déployer des solutions algo        █████████ 125 h
...

Extensions possibles :
- Ajouter un graphe par semestre (/api/heures-par-semestre)
- Exporter les données en CSV ou JSON
- Créer une interface de filtrage (par compétence, semestre, etc.)
- Ajouter un frontend React ou Vue.js plus dynamique

Auteur :
Projet pédagogique réalisé pour le BUT Science des Données
Direction : Dorine [Nom] — Département SD, Dole / Besançon
